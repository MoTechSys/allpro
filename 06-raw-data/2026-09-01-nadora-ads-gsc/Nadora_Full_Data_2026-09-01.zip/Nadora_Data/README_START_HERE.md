# حزمة بيانات Nadora — سحب شامل من Google Ads + Google Search Console

> **للوكلاء / المطورين:** هذا الملف هو الفهرس الكامل. اقرأه أولاً قبل فتح أي ملف آخر.

---

## 0. ملخص الحزمة

| البند | القيمة |
|---|---|
| الحساب الإعلاني | `3412658939` — keifaldiafa.com — العملة **SAR** — التوقيت Asia/Riyadh |
| الحساب المدير | `7947566294` — كيف الضيافة |
| الموقع في Search Console | `https://keifaldiafa.com/` — الصلاحية **siteOwner** |
| فترة بيانات Google Ads | **2023-02-01 → 2026-09-01** (كل ما هو متاح فعلياً) |
| فترة بيانات Search Console | **2025-04 → 2026-08** (⚠️ لا توجد بيانات قبل أبريل 2025 — الموقع لم يكن موثّقاً في GSC قبل هذا التاريخ) |
| عدد تقارير Google Ads | **90 من 91** نجحت |
| إجمالي الملفات | 400+ ملف |
| مصدر البيانات | Google Ads API v24 (GAQL) + Search Console API v3 + URL Inspection API — سحب مباشر حي، ليس تصدير يدوي |

---

## 1. الأرقام الكبرى (خلاصة سريعة)

### Google Ads — الإجمالي 2023 → 2026
```
الظهور (Impressions)  : 1,416,900
النقرات (Clicks)      :    22,748
الإنفاق               : 66,655.99 SAR
التحويلات             :       226
متوسط تكلفة النقرة    :      2.93 SAR
تكلفة التحويل (CPA)   :    294.94 SAR
مصطلحات بحث فريدة     :     2,608
عدد الحملات           :         6
```

### التوزيع السنوي
| السنة | الظهور | النقرات | الإنفاق SAR | ملاحظة |
|---|---|---|---|---|
| 2023 | 503,117 | 8,084 | 15,352.90 | |
| 2024 | 883,653 | 12,050 | 31,126.03 | ذروة الإنفاق |
| 2025 | 17,968 | 1,653 | 15,930.75 | تحوّل لحملات أدق |
| 2026 | 12,162 | 961 | 4,246.31 | **190 تحويل، CPA = 22.35 SAR** ← الأداء الأفضل بفارق ضخم |

### Google Search Console (عضوي، 2025-04 → 2026-08)
```
النقرات   :    816
الظهور    : 44,843
CTR       :  1.82%
كلمات بحث :    802
صفحات     :     42
```

### أهم 3 استنتاجات
1. **«قهوجي» + «صبابين قهوة» + «مباشرين»** = محرك الطلب الأساسي (أكثر من 51,743 ظهور لكلمة «قهوجي» وحدها).
2. **جدة** تستحوذ على معظم الطلب (29,922 ظهور / 19,408 SAR إنفاق) — لكن **الرياض ومكة والدمام طلب غير مُستغل**.
3. **76 مصطلح** ندفع فيه إعلانات ولا توجد له صفحة عضوية = **3,803 SAR إنفاق قابل للتوفير** ببناء محتوى.

---

## 2. من أين تبدأ؟ (ترتيب القراءة الموصى به للوكلاء)

| # | الملف | لماذا |
|---|---|---|
| 1️⃣ | `insights/00_ANALYSIS_REPORT.txt` | **التقرير التحليلي الكامل** — 18 قسم بالعربي. اقرأه بالكامل أولاً |
| 2️⃣ | `insights/17_nadora_page_plan.csv` | **خطة صفحات Nadora الجاهزة** — 22 صفحة مقترحة مع URL slug + العنوان + الكلمات المستهدفة |
| 3️⃣ | `insights/03_search_terms_aggregated.csv` | 2,608 مصطلح بحث حقيقي مجمّع مع الأداء |
| 4️⃣ | `insights/08_paid_only_gap.csv` | الفجوة: ندفع فيها ولا نملك صفحة |
| 5️⃣ | `insights/07_seo_opportunities.csv` | فرص SEO: ظهور عالي + CTR منخفض |
| 6️⃣ | `insights/05_demand_by_city.csv` + `04_demand_by_service.csv` | خريطة الطلب حسب المدينة والخدمة |

---

## 3. مجلد `insights/` — التحليل الجاهز (ابدأ من هنا)

| الملف | الصفوف | المحتوى |
|---|---|---|
| `00_ANALYSIS_REPORT.txt` | 59 KB | **التقرير الرئيسي** — 18 قسم تحليلي بالعربي |
| `01_ads_yearly.csv` | 4 | أداء الإعلانات سنوياً |
| `02_campaigns.csv` | 6 | أداء كل حملة |
| `03_search_terms_aggregated.csv` ⭐ | 2,608 | **كل مصطلح بحث** + ظهور/نقرات/CTR/تكلفة/تحويلات + المدينة + الخدمة + الحملات |
| `04_demand_by_service.csv` | 16 | الطلب مجمّع حسب نوع الخدمة (قهوجي، صبابين، مباشرين، ضيافة…) |
| `05_demand_by_city.csv` ⭐ | 19 | الطلب مجمّع حسب المدينة (جدة، الرياض، مكة، الدمام…) |
| `07_seo_opportunities.csv` | 40 | كلمات ظهورها ≥100 و CTR <3% + النقرات الإضافية الممكنة |
| `08_paid_only_gap.csv` ⭐ | 40 | مصطلحات مدفوعة بلا صفحة عضوية = فرص محتوى |
| `10_devices.csv` | 8 | الأجهزة (Ads + GSC) |
| `11_demo_الجنس.csv` / `العمر` / `الأبوة` / `الدخل` | 3-7 | الديموغرافيا |
| `12_by_hour.csv` | 24 | الأداء حسب الساعة (الذروة 18:00 = 1,491 نقرة) |
| `12_by_dayofweek.csv` | 7 | الأداء حسب اليوم (الخميس الأقوى = 4,045 نقرة) |
| `13_best_ad_copy.csv` | 252 | أفضل نصوص الإعلانات أداءً — استخدمها في العناوين والوصف |
| `14_negative_keywords.csv` | 203 | الكلمات السلبية — لا تبنِ عليها محتوى |
| `15_conversions.csv` | 7 | التحويلات (واتساب 197 · اتصال 29) |
| `16_monthly_combined.csv` | 45 | مقارنة شهرية: مدفوع مقابل عضوي |
| `17_nadora_page_plan.csv` ⭐⭐ | 22 | **خطة صفحات Nadora**: `priority_score, suggested_url, page_title_ar, city, service, impressions, clicks, spend, conversions, target_keywords, keyword_count` |

### أهم 4 صفحات مقترحة (من `17_nadora_page_plan.csv`)
| URL | العنوان | ظهور | نقرات | إنفاق SAR | كلمات |
|---|---|---|---|---|---|
| `/qahwaji-jeddah` | قهوجي جدة | 20,521 | 2,654 | 11,911 | 75 |
| `/sababin-qahwa-jeddah` | صبابين قهوة جدة | 4,975 | 863 | 3,730 | 23 |
| `/qahwaji-riyadh` | قهوجي الرياض | — | — | — | — |
| `/mubashirin-jeddah` | مباشرين جدة | — | — | — | — |

---

## 4. مجلد `ads/` — بيانات Google Ads الخام (90 تقرير)

كل ملف CSV بترميز UTF-8-BOM (يفتح مباشرة في Excel بالعربي). نسخة JSON الخام لكل تقرير في `ads/_raw/`.

### A — الحساب والفوترة
| الملف | صفوف | المحتوى |
|---|---|---|
| `A01_customer_info.csv` | 10 | بيانات الحساب، العملة، التوقيت |
| `A02_customer_clients.csv` | 1 | العملاء التابعون |
| `A03_manager_clients.csv` | 1 | عملاء الحساب المدير |
| `A04_billing_setup.csv` | 1 | إعداد الفوترة |

### B — الحملات
| الملف | صفوف | المحتوى |
|---|---|---|
| `B01_campaigns_settings.csv` | 6 | كل إعدادات الحملات |
| `B02_campaign_perf_total.csv` | 6 | الأداء الإجمالي لكل حملة |
| `B03_campaign_perf_daily.csv` | 872 | **الأداء اليومي** لكل حملة |
| `B04_campaign_perf_monthly.csv` | 49 | الأداء الشهري |
| `B05_campaign_perf_yearly.csv` | 9 | الأداء السنوي |
| `B06_campaign_perf_by_device.csv` | 19 | حسب الجهاز |
| `B07_campaign_perf_by_network.csv` | 10 | حسب الشبكة (بحث/شركاء/عرض) |
| `B08_campaign_perf_by_hour.csv` | 139 | حسب الساعة |
| `B09_campaign_perf_by_dayofweek.csv` | 36 | حسب يوم الأسبوع |
| `B10_campaign_budgets.csv` | 9 | الميزانيات |
| `B11_bidding_strategies.csv` | 1 | استراتيجيات المزايدة |

### C — المجموعات الإعلانية
`C01_ad_groups_settings.csv` (21) · `C02_adgroup_perf_total.csv` (21) · `C03_adgroup_perf_monthly.csv` (63) · `C04_adgroup_perf_by_device.csv` (38)

### D — الكلمات المفتاحية والسلبية
| الملف | صفوف | المحتوى |
|---|---|---|
| `D01_keywords_settings.csv` | 2,712 | **كل الكلمات المفتاحية** + نوع المطابقة + الحالة |
| `D02_keywords_perf_total.csv` | 2,723 | أداء كل كلمة |
| `D03_keywords_perf_monthly.csv` | 1,177 | شهرياً |
| `D04_keywords_perf_by_device.csv` | 684 | حسب الجهاز |
| `D05_negative_keywords_campaign.csv` | 226 | الكلمات السلبية على مستوى الحملة |
| `D06/D07/D08` | 0 | فارغة (لا توجد قوائم سلبية مشتركة) |

### E — مصطلحات البحث ⭐ (الأهم لبناء المحتوى)
| الملف | صفوف | المحتوى |
|---|---|---|
| `E01_search_terms_total.csv` ⭐ | 4,277 | **ما كتبه الناس فعلاً في جوجل** + الأداء الكامل |
| `E02_search_terms_monthly.csv` | 7,834 | نفس الشيء موزّع شهرياً — لرصد الترند |
| `E03_search_terms_by_device.csv` | 4,083 | حسب الجهاز |

### F — الإعلانات
`F01_ads_full.csv` (22 — نصوص الإعلانات كاملة) · `F02_ads_perf.csv` (22) · `F03_ads_perf_monthly.csv` (63)

### G — الأصول (Assets)
`G01_assets.csv` (430 — كل العناوين والأوصاف والصور) · `G02_ad_group_ad_asset_view.csv` (549) · `G03_campaign_asset.csv` (115) · `G04_customer_asset.csv` (6) · `G05_asset_group.csv` (1) · `G06_asset_group_asset.csv` (26) · `G07` فارغ

### H — الجغرافيا
`H01_geo_targets_campaign.csv` (26 — الاستهداف الجغرافي) · `H02_geographic_view.csv` (10) · `H03_user_location_view.csv` (70 — **الموقع الفعلي للمستخدم**) · `H04_location_view.csv` (40)

### I — الجمهور والديموغرافيا
`I01` فارغ · `I02_user_lists.csv` (8) · `I03_campaign_audience_view.csv` (26) · `I04` فارغ · `I05_gender_view.csv` (63) · `I06_age_range_view.csv` (147) · `I07_parental_status_view.csv` (63) · `I08_income_range_view.csv` (147)

> ذكور 70.8% · الفئة 25-34 = 33% · الفئة 35-44 = 21.5%

### J — التحويلات
`J01_conversion_actions.csv` (14) · `J02_conv_by_action_campaign.csv` (16) · `J03_conv_by_action_monthly.csv` (70) · `J04_conversion_goal_campaign_config.csv` (6) · `J05_customer_conversion_goal.csv` (9)

> **واتساب 197 تحويل · الاتصال 29** — واتساب هو القناة المهيمنة، صمّم صفحات Nadora حولها.

### K — شبكة العرض والمواضع
`K01` فارغ · `K02_detail_placement_view.csv` (10,350 — **كل موقع/تطبيق ظهر فيه الإعلان**) · `K03_group_placement_view.csv` (3,744) · `K04` فارغ · `K05_display_keyword_view.csv` (2,398)

### L — التوصيات وسجل التغييرات
`L01_recommendations.csv` (6 — توصيات جوجل الحالية) · `L02_change_status.csv` (3,067) · `L03_change_event.csv` (114 — **سجل التغييرات التفصيلي**) · `L04` فارغ · `L05_ad_schedule.csv` (21) · `L06_device_bid_modifiers.csv` (19) · `L07_language_targeting.csv` (11) · `L08_all_campaign_criteria.csv` (329)

### M — مستوى الحساب والصفحات المقصودة
| الملف | صفوف | المحتوى |
|---|---|---|
| `M01_account_perf_monthly.csv` | 40 | الحساب شهرياً |
| `M02_account_perf_daily.csv` | 856 | **الحساب يومياً** |
| `M03/M04/M05` | 5/4/4 | جهاز / شبكة / سنة |
| `M06_click_view_individual.csv` ⭐ | 558 | **كل نقرة على حدة** (آخر 30 يوم — سقف Google API) |
| `M07_landing_page_view.csv` | 32 | الصفحات المقصودة |
| `M08_expanded_landing_page_view.csv` | 5,095 | **الصفحات المقصودة الموسّعة** — مهم جداً لمعرفة أداء كل URL |
| `M12_campaign_search_term_insight.csv` | 19 | رؤى مصطلحات البحث لكل حملة |
| `M13_customer_search_term_insight.csv` | 9 | رؤى على مستوى الحساب |
| `M18_asset_set.csv` / `M20_account_budget.csv` | 1 / 1 | |
| `M09, M10, M11, M14–M17, M19` | 0 | فارغة (خدمات غير مفعّلة: فيديو/شوبنق/تجارب/محاكاة) |

### ملفات مساعدة
- `ads/_summary.csv` (104) + `_summary.json` — حالة كل تقرير ونتيجته
- `ads/_log.txt` + `_log_fix.txt` — سجل التنفيذ الكامل
- `ads/_raw/` (89 ملف JSON) — الاستجابة الخام من API لكل تقرير
- `ads/_errors/` — 3 تقارير فقط لم تنجح + `_resolved_later/` (15 خطأ تم إصلاحها لاحقاً، محفوظة للتوثيق)

---

## 5. مجلد `gsc/` — بيانات Search Console

> ⚠️ **البيانات تبدأ من 2025-04**. كل الشهور 2023-01 → 2025-03 ترجع صفراً لأن الموقع لم يكن موثّقاً في GSC قبل أبريل 2025. تم سحب كل الشهور على أي حال للتوثيق.

### الأساسيات
`00_sites.json` (المواقع والصلاحيات) · `01_sitemaps.json` (3 خرائط: 40+4+44 رابط، 388 صورة — **كلها indexed=0**)

### بُعد واحد (`10_*`)
`10_by_query.csv` (802 — **كل كلمة بحث عضوية**) · `10_by_page.csv` (42) · `10_by_country.csv` (166) · `10_by_device.csv` (3) · `10_by_date.csv` (498 — يومياً)

### تقاطع بُعدين (`20_*`)
`20_query_x_date.csv` (13,451) · `20_query_x_page.csv` (1,414 — **أي كلمة تجيب أي صفحة**) · `20_query_x_country.csv` (2,945) · `20_query_x_device.csv` (1,116) · `20_page_x_date.csv` (2,937) · `20_page_x_country.csv` (512) · `20_page_x_device.csv` (96) · `20_date_x_country.csv` (8,648) · `20_date_x_device.csv` (1,180) · `20_country_x_device.csv` (327)

### تقاطع ثلاثة أبعاد (`30_*`)
`30_date_x_query_x_page.csv` (15,898 — **أدق ملف في GSC**) · `30_query_x_page_x_country.csv` (3,657) · `30_query_x_country_x_device.csv` (3,592) · `30_query_x_page_x_device.csv` (1,935) · `30_page_x_country_x_device.csv` (820)

### أنواع البحث (`40_/41_/42_*`)
web · image · video · news · discover · googleNews — مقسّمة حسب query / page / date.
> `40_type_image_by_query.csv` (345) — **بحث الصور نشط**، فرصة مهملة لـ Nadora.

### التجميعات الزمنية
`50_monthly_summary.csv` (44 شهر) · `51_yearly_summary.csv` (4) · `monthly/` (88 ملف: queries + pages لكل شهر) · `yearly/` (8 ملفات)

### فحص الروابط
`60_url_inspection.csv` / `.json` (40) — **نتيجة URL Inspection API لأهم 40 صفحة**: حالة الفهرسة، الزحف، AMP، الأخطاء.

### مساعدات
`_meta.json` · `_log.txt` · `_raw/` (37 JSON) · `_errors/` (4 — قيود API معروفة: searchAppearance لا يُدمج مع بُعد آخر، و DISCOVER/GOOGLE_NEWS لا يقبلان التجميع بـ query)

---

## 6. ملاحظات فنية مهمة للوكلاء

1. **العملة SAR** في كل ملفات Ads. القيم الأصلية من API بـ micros — تم تحويلها بالقسمة على 1,000,000.
2. **ترميز CSV = UTF-8 with BOM** — يفتح في Excel بالعربي بدون تشويش.
3. **الفرق بين Keywords و Search Terms:** `D0*` = ما استهدفناه نحن. `E0*` = ما كتبه الناس فعلاً. **لبناء صفحات Nadora استخدم `E01` و `insights/03`** — هي صوت العميل الحقيقي.
4. **الجوال يسيطر:** 94.9% من ظهور الإعلانات على الموبايل (1,344,893). وفي GSC: موبايل 59,747 ظهور بمتوسط ترتيب 8.1 مقابل ديسكتوب 14,459 بترتيب 15.8. → **Nadora يجب أن يكون mobile-first إجبارياً**.
5. **خرائط الموقع كلها `indexed=0`** — مشكلة فهرسة قائمة يجب معالجتها في Nadora من اليوم الأول.
6. **أقصى نقرات مجانية ممكنة شهرياً = 4,732** حسب تحليل فرص SEO في `insights/07`.
7. **الصفحات المدفوعة**: راجع `M08_expanded_landing_page_view.csv` (5,095 صف) لمعرفة أي landing page كان أداؤها الأفضل قبل إعادة بنائها في Nadora.
8. الملفات ذات 0 صف موجودة عمداً — لتوثيق أن السحب تم ولا توجد بيانات هناك (خدمة غير مفعّلة).

---

## 7. بنية المجلدات

```
/
├── README_ابدأ_من_هنا.md          ← أنت هنا
├── insights/                       ⭐ التحليل الجاهز (ابدأ هنا)
│   ├── 00_ANALYSIS_REPORT.txt      ⭐⭐ التقرير الرئيسي 18 قسم
│   ├── 17_nadora_page_plan.csv     ⭐⭐ خطة صفحات Nadora
│   └── … 18 ملف CSV آخر
├── ads/                            بيانات Google Ads (90 تقرير)
│   ├── A01…M20  *.csv
│   ├── _raw/    (89 JSON خام)
│   ├── _errors/ (3 + _resolved_later/)
│   ├── _summary.csv / _summary.json
│   └── _log.txt / _log_fix.txt
└── gsc/                            بيانات Search Console
    ├── 00/01  (مواقع + خرائط)
    ├── 10_/20_/30_  (تقاطعات الأبعاد)
    ├── 40_/41_/42_  (أنواع البحث)
    ├── 50_/51_      (تجميع زمني)
    ├── 60_          (فحص الروابط)
    ├── monthly/ (88) · yearly/ (8)
    ├── _raw/ (37) · _errors/ (4)
    └── _meta.json / _log.txt
```

---

**تاريخ السحب:** 2026-09-01 · **المصدر:** Google Ads API v24 + Search Console API v3 (سحب حي مباشر)
